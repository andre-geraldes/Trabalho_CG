#ifndef _MAIN
#define _MAIN

#define _USE_MATH_DEFINES

#include <stdlib.h>
#include <stdio.h>
#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <vector>

#include "patch.h"
#include "ponto.h"

using namespace std;

vector<Patch> patchs;
vector<Ponto> vertices;

#endif