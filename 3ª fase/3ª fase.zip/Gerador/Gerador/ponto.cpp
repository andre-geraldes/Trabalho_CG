#include "Ponto.h"

Ponto::Ponto() {
	x = 0;
	y = 0;
	z = 0;
}

Ponto::Ponto(float xx, float yy, float zz){
	x = xx;
	y = yy;
	z = zz;
}

Ponto::~Ponto(void)
{
}