#include "Patch.h"


Patch::Patch() {
}

void Patch::adicionaIndice(int i) {
	indices.push_back(i);
}

Patch::~Patch()
{
}